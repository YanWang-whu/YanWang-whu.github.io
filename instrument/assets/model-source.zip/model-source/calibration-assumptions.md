# Independent calibration accessory model

`calibration.py` defines `build_calibration(parent=None)`, with no scene-clearing or export actions on import. The function returns the `CALIBRATION_ACCESSORIES` root, in metres with Z up and local floor at z=0. It can be imported alongside `geometry.py` and positioned, rotated or hidden as a complete unit. It does not import or modify `build_instrument.py` and has no connection to the cage assembly.

## Source boundary

This is a proposed calibration accessory layout based on the final September 3, 2026 funding documents:

- `C:\Users\asus\Desktop\文件2\科研学术活动\宇树\资助申请书_YanWang.docx` and matching PDF.
- `C:\Users\asus\Desktop\文件2\科研学术活动\宇树\项目实施计划_YanWang.docx` and matching PDF.

Exact evidence and page references: `work-notes/funding-instrument-evidence.md`, especially calibration/reference section and implementation plan pp9–11,13–14,16. P38 names a Cambro 12 qt container; P23 an Inkbird ISV-100W circulator; P10 a three-wire PT100; P11 a MAX31865 interface. The documents require a matte reference/target with four registration marks, contact reference on the back of the reference surface, and a sealed warm-water surrogate for empty-cage coverage checks.

The supplied documents do not establish exact hardware outer dimensions for these particular calibration parts. **Every modeled shape and every assembly position is labelled `proposed approximation; not manufacturer CAD`.** Product names identify the proposal BOM; this is not a dimensionally certified replica or evidence that any hardware has been purchased, constructed or validated.

## Assumptions recorded explicitly

| Modeled element | Proposed approximation used | Reason / limit |
|---|---|---|
| Independent tray | 590 × 366 × 12 mm top, four silicone feet, front identification rail | Designed arrangement to organize accessories; not a new claimed purchase or connection to the main rig. |
| Bath container | 280 × 260 × 195 mm representative tapered body above the tray | Only 12 qt capacity/model family is sourced. Exact Cambro SKU, wall thickness, taper and grip geometry are unknown. Water shape/fill is illustrative; mesh volume does not certify capacity. |
| ISV-100W | Representative immersion sleeve, graphite upper body, top control face and rear clamp; overall model about 320 mm tall | Dimensions, controls, clamp, intake recesses and materials are visual approximations. Display remains unpowered and provides no numeric measurement. |
| Circulator power | Parked disconnected cord and plug | A bath accessory, separate from monitoring electronics. No mains wiring schematic or control connection is represented. |
| Sealed target | Approximate 111 × 78 × 24 mm matte capsule plus adjacent 43 × 70 mm reference surface | Illustration of transfer/coverage targets, not a calibrated blackbody. No temperature, emissivity value or thermal uniformity is asserted. |
| Four registration marks | Four small geometric checker fiducials at the target plane | Positions and pattern designed for visibility; no claim of an established optical calibration target. |
| Reference support | Open-bottom backing frame and two-post stand | Supports leave access for the contact probe; they are proposed fixtures. Reference and target front surfaces share z=149 mm in this layout. |
| PT100 | Representative metal sheath, rear contact, two red leads and one white lead | Metal tip touches the back of the reference skin at z=148 mm. Three-wire color scheme is illustrative; no exact probe vendor, length or connector pinout is supplied. No animal core-temperature measurement. |
| MAX31865 | Approximate 53 × 32 mm breakout board in a shallow carrier, three-way RTD terminal and readout header | The exact breakout vendor/PCB dimensions and circuit layout are not established. Passives, terminal spacing and contacts are illustrative. |
| Readout line | Separate parked interface lead with unconnected end | Indicates an independent data path. Not a pin-accurate wiring diagram or invented standalone logger/display. |
| Surface materials | Clear bath polymer, stainless sleeve/probe, matte target, polymer handles and PCB finishes | Professional rendering approximations. Optical and thermal material parameters are not validated engineering specifications. |

No human, animal, induction, ultrasound, cage, main acquisition computer or environmental actuation is modeled. The water bath circulator belongs to this separate calibration accessory group; it does not turn the monitor into a closed-loop induction device.

## Build and integration

```python
from calibration import build_calibration
calibration = build_calibration(parent=None)
calibration.location = (0.0, 0.0, 0.0)  # choose a separate location/view
```

Toggle this root and its descendants in the viewer, or load the separate `calibration-accessories.glb` as a second scene. The GLB uses standard glTF Y-up export conversion; the source geometry and editable Blender master use Z-up. In a Three.js viewer the exported GLB needs no manual corrective X rotation. The source root and six component groups are retained with metadata.

Standalone command (PowerShell):

```powershell
& 'C:\Users\asus\Documents\ChatGPT\网站\tools\blender-4.5.13-windows-x64\blender.exe' --background --python 'C:\Users\asus\Documents\ChatGPT\网站\model-source\calibration.py' -- --render --samples 32
```

Default outputs: `model-output/calibration/calibration-accessories.glb`, editable `.blend`, `calibration-preview.png`, and `calibration-audit.json`. The exporter checks the complete accessory mesh remains below 30,000 triangles, excludes studio/camera/lights from GLB, and writes numeric bounds and component IDs to the audit.
