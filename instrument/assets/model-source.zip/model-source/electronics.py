"""Cage-external acquisition electronics, Blender 4.5+, metres, Z-up.

Public entry: build_electronics(parent=None, ups_drop=0.0) -> origin Empty.
No scene reset, lights, cameras, render, save, third-party addon, or external asset.
Hardware envelope sources and deliberate approximations: electronics-manifest.md.
Meshes are accumulated by material within independently movable semantic groups.
"""
import bpy
import math
import json
from mathutils import Vector, Matrix

PI_CENTER = (-0.055, 0.008, 0.0)
HUB_CENTER = (0.051, -0.002, 0.0)
UPS_CENTER = (0.340, 0.000, 0.0)
SOURCE_URLS = {
    'pi5': 'https://datasheets.raspberrypi.com/rpi5/raspberry-pi-5-mechanical-drawing.pdf',
    'hub': 'https://www.startech.com/en-us/usb-hubs/st53004u1c',
    'flash': 'https://www.raspberrypi.com/documentation/accessories/usb.html#flash-drive-dimensions',
    'ups': 'https://www.se.com/us/en/product/BE600M1/apc-backups-600va-120v-1-usb-charging-port-7-nema-outlets-2-surge/',
    'pi_psu': 'https://datasheets.raspberrypi.com/power-supply/27w-usb-c-power-supply-product-brief.pdf',
}

# Fixed default coordinates in Electronics_Assembly-local metres. Empty anchors
# below follow their actual component when the master changes an assembly layout.
ANCHORS = {
    'thermal_usb_in': {'name':'EL_USB_Thermal_Camera_In','position':(.0625,-.0355,.0305),'normal':(0,-1,0)},
    'auxiliary_usb_in': {'name':'EL_USB_Auxiliary_In','position':(.0855,-.0355,.0305),'normal':(0,-1,0)},
    'camera_csi_in': {'name':'EL_CSI_Camera_In','position':(-.088,.022,.0338),'normal':(0,1,0)},
    'camera_csi_case_exit': {'name':'EL_CSI_Case_Exit','position':(-.085,.044,.040),'normal':(0,1,0)},
    'ambient_i2c_in': {'name':'EL_Ambient_I2C_In','position':(.0595,.058,.0295),'normal':(1,0,0)},
    'pi_gpio_i2c': {'name':'EL_Pi_GPIO_I2C','position':(-.0865,.0333,.0395),'normal':(0,0,1)},
    'primary_usb_c_feed': {'name':'EL_Primary_USB_C_Feed','position':(.221,-.021,.165),'normal':(-1,0,0),'moves_with_ups':True},
    'pi_usb_c_in': {'name':'EL_Pi_USB_C_In','position':(-.087,-.023,.033),'normal':(0,-1,0)},
    'pi_adapter_ac_in': {'name':'EL_Pi_27W_AC_In','position':(.242,-.021,.139),'normal':(0,0,-1),'moves_with_ups':True},
    'hub_adapter_ac_in': {'name':'EL_Hub_Adapter_AC_In','position':(.291,-.021,.139),'normal':(0,0,-1),'moves_with_ups':True},
    'hub_adapter_dc_out': {'name':'EL_Hub_Adapter_DC_Out','position':(.291,.007,.158),'normal':(0,1,0),'moves_with_ups':True},
    'hub_dc_in': {'name':'EL_Hub_DC_In','position':(.024,.0292,.031),'normal':(0,1,0)},
    'ups_ac_in_plug': {'name':'EL_UPS_AC_In','position':(.4235,-.073,.008),'normal':(-1,0,0),'moves_with_ups':True},
    'ups_backup_out_1': {'name':'EL_UPS_Backup_Out_1','position':(.242,-.021,.139),'normal':(0,0,1),'moves_with_ups':True},
    'ups_backup_out_2': {'name':'EL_UPS_Backup_Out_2','position':(.291,-.021,.139),'normal':(0,0,1),'moves_with_ups':True},
}


def _material(key, rgb, metal=0.0, rough=0.4, emission=0.0):
    name = 'EL_' + key
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat  # Preserve any material tuning made by the importing master.
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    bs = mat.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = (*rgb, 1)
    bs.inputs['Metallic'].default_value = metal
    bs.inputs['Roughness'].default_value = rough
    if emission:
        bs.inputs['Emission Color'].default_value = (*rgb, 1)
        bs.inputs['Emission Strength'].default_value = emission
    mat.diffuse_color = (*rgb, 1)
    return mat


def _palette():
    return {
        'case': _material('Graphite_case', (.085, .095, .110), .12, .33),
        'rubber': _material('Rubber_and_recess', (.012, .016, .020), 0, .62),
        'silver': _material('Satin_metal', (.48, .53, .58), .82, .27),
        'pcb': _material('PCB_soldermask', (.026, .19, .080), .12, .42),
        'silicon': _material('IC_packages', (.017, .022, .027), .04, .36),
        'gold': _material('Contact_gold', (.64, .40, .095), .80, .29),
        'blue': _material('USB3_insert', (.026, .105, .42), 0, .38),
        'rtc': _material('RTC_soldermask', (.020, .105, .21), .1, .41),
        'led': _material('Status_lens', (.18, .60, .24), 0, .21, .18),
        'blue_led': _material('Blue_status_lens', (.05, .28, .90), 0, .21, .10),
        'psu': _material('Pi_power_supply_shell', (.76, .79, .81), 0, .32),
    }


class _Bundle:
    """Batches loose geometry per material, with no scene-global operators."""
    def __init__(self, name, parent, materials, origin=(0, 0, 0), explode=(0, 0, 0)):
        self.root = bpy.data.objects.new(name, None)
        bpy.context.collection.objects.link(self.root)
        self.root.parent = parent
        self.root.location = origin
        self.root.empty_display_type = 'PLAIN_AXES'
        self.root.empty_display_size = .012
        self.root['component_id'] = name
        self.root['home_position'] = list(origin)
        self.root['explode_offset'] = list(explode)
        self.root['asset_role'] = 'proposed_monitoring_assembly'
        self.parts = {}
        self.materials = materials

    def add(self, key, verts, faces, smooth=None):
        data = self.parts.setdefault(key, [[], [], []])
        n = len(data[0])
        data[0].extend(tuple(v) for v in verts)
        data[1].extend(tuple(n+i for i in f) for f in faces)
        data[2].extend(smooth if smooth is not None else [False]*len(faces))

    def finish(self):
        for key, (verts, faces, smooth) in self.parts.items():
            mesh = bpy.data.meshes.new(self.root.name + '_' + key)
            mesh.from_pydata(verts, [], faces)
            mesh.update()
            for polygon,flag in zip(mesh.polygons,smooth):polygon.use_smooth=flag
            mesh.materials.append(self.materials[key])
            obj = bpy.data.objects.new(mesh.name, mesh)
            bpy.context.collection.objects.link(obj)
            obj.parent = self.root
            # Planar faces stay planar; bevel faces provide real highlight geometry.
            obj['component_id'] = self.root.name
            obj['material_role'] = key
        return self.root


def _outline(w, d, radius, segments=3):
    r = max(.000001, min(radius, w*.499, d*.499))
    points = []
    for cx, cy, angle in ((w/2-r, d/2-r, 0), (-w/2+r, d/2-r, 90),
                          (-w/2+r, -d/2+r, 180), (w/2-r, -d/2+r, 270)):
        for k in range(segments+1):
            a = math.radians(angle+90*k/segments)
            points.append((cx+r*math.cos(a), cy+r*math.sin(a)))
    return points


def _box(b, key, center, size, radius=.0006, bevel=.00025, seg=2, rotation=None):
    w, d, h = size
    e = min(bevel, h*.30, w*.10, d*.10)
    profiles = [(w-2*e, d-2*e, max(radius-e, .000001), -h/2),
                (w, d, radius, -h/2+e), (w, d, radius, h/2-e),
                (w-2*e, d-2*e, max(radius-e, .000001), h/2)] if e else [(w,d,radius,-h/2),(w,d,radius,h/2)]
    verts = [(x,y,z) for pw,pd,pr,z in profiles for x,y in _outline(pw,pd,pr,seg)]
    n = len(verts)//len(profiles)
    faces = [tuple(reversed(range(n))), tuple(range((len(profiles)-1)*n,len(verts)))]
    for j in range(len(profiles)-1):
        for i in range(n):
            k=(i+1)%n
            faces.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
    mat = rotation or Matrix.Identity(3)
    b.add(key, [mat@Vector(v)+Vector(center) for v in verts], faces)


def _ring(b, key, center, outer, inner, height, radius=.002, inner_radius=.001, seg=4, rotation=None):
    outlines = [_outline(*outer,radius,seg),_outline(*inner,inner_radius,seg)]
    n=len(outlines[0]); verts=[]
    for z in (-height/2,height/2):
        for line in outlines:
            verts.extend((center[0]+x,center[1]+y,center[2]+z) for x,y in line)
    faces=[]
    for i in range(n):
        j=(i+1)%n
        faces += [(i,j,2*n+j,2*n+i), (n+j,n+i,3*n+i,3*n+j),
                  (j,i,n+i,n+j), (2*n+i,2*n+j,3*n+j,3*n+i)]
    if rotation is not None:verts=[rotation@(Vector(v)-Vector(center))+Vector(center) for v in verts]
    b.add(key,verts,faces)


def _cylinder(b,key,center,radius,depth,sides=16,axis='Z', bevel=.0002):
    e=min(bevel,depth*.3,radius*.3)
    rings=[(radius-e,-depth/2),(radius,-depth/2+e),(radius,depth/2-e),(radius-e,depth/2)]
    rot = Matrix.Rotation(math.pi/2,3,'Y') if axis=='X' else Matrix.Rotation(math.pi/2,3,'X') if axis=='Y' else Matrix.Identity(3)
    verts=[rot@Vector((r*math.cos(i*math.tau/sides),r*math.sin(i*math.tau/sides),z))+Vector(center) for r,z in rings for i in range(sides)]
    faces=[tuple(reversed(range(sides))),tuple(range(3*sides,4*sides))]
    for k in range(3):
        faces += [(k*sides+i,k*sides+(i+1)%sides,(k+1)*sides+(i+1)%sides,(k+1)*sides+i) for i in range(sides)]
    b.add(key,verts,faces,[False,False]+[True]*(len(faces)-2))


def _tube(b,key,points,radius=.0017,sides=8,subdiv=5):
    p=[Vector(v) for v in points]; smooth=[]
    for i in range(len(p)-1):
        a=p[max(0,i-1)]; c=p[i]; d=p[i+1]; e=p[min(len(p)-1,i+2)]
        for j in range(subdiv):
            t=j/subdiv
            smooth.append(.5*((2*c)+(-a+d)*t+(2*a-5*c+4*d-e)*t*t+(-a+3*c-3*d+e)*t*t*t))
    smooth.append(p[-1]); verts=[]
    for i,c in enumerate(smooth):
        tangent=(smooth[min(i+1,len(smooth)-1)]-smooth[max(0,i-1)]).normalized()
        ref=Vector((0,0,1)) if abs(tangent.z)<.95 else Vector((0,1,0))
        u=tangent.cross(ref).normalized();v=tangent.cross(u).normalized()
        verts += [c+radius*(u*math.cos(j*math.tau/sides)+v*math.sin(j*math.tau/sides)) for j in range(sides)]
    faces=[tuple(reversed(range(sides))),tuple(range((len(smooth)-1)*sides,len(smooth)*sides))]
    for i in range(len(smooth)-1):
        faces += [(i*sides+j,i*sides+(j+1)%sides,(i+1)*sides+(j+1)%sides,(i+1)*sides+j) for j in range(sides)]
    b.add(key,verts,faces,[False,False]+[True]*(len(faces)-2))
    return smooth


def _screw(b,center,r=.0016):
    _cylinder(b,'silver',center,r,.0008,12)
    # Two inset dark slots read as a cross recess without expensive thread geometry.
    for dims in ((r*1.25,r*.23,.00004),(r*.23,r*1.25,.00004)):
        _box(b,'case',(center[0],center[1],center[2]+.00042),dims,.00005,0,1)


def _text(b,key,text,loc,size=.0025,rotation=None):
    curve=bpy.data.curves.new('EL_temporary_text','FONT')
    curve.body=text;curve.size=size;curve.extrude=0;curve.resolution_u=2
    curve.align_x='CENTER';curve.align_y='CENTER'
    obj=bpy.data.objects.new('EL_temporary_text',curve)
    bpy.context.collection.objects.link(obj)
    mesh=bpy.data.meshes.new_from_object(obj.evaluated_get(bpy.context.evaluated_depsgraph_get()))
    mat=rotation or Matrix.Identity(3)
    b.add(key,[mat@v.co+Vector(loc) for v in mesh.vertices],[tuple(p.vertices) for p in mesh.polygons])
    bpy.data.objects.remove(obj,do_unlink=True);bpy.data.curves.remove(curve);bpy.data.meshes.remove(mesh)


def _anchor(name,parent,position,normal):
    obj=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(obj)
    obj.parent=parent;obj.location=position;obj.empty_display_size=.003
    obj['connector_normal']=list(normal);obj['purpose']='external cable docking reference'
    return obj


def _drill_board(board_root,materials):
    """Four actual mounting holes, evaluated locally without changing selection."""
    pcb=next(o for o in board_root.children if o.type=='MESH' and o.get('material_role')=='pcb')
    temporary=_Bundle('EL_Temporary_Board_Drill',board_root,materials)
    for x in (-.039,.019):
        for y in (-.0245,.0245): _cylinder(temporary,'silver',(x,y,.0303),.00135,.005,20,bevel=0)
    temporary.finish();cutter=next(o for o in temporary.root.children if o.type=='MESH')
    bpy.context.view_layer.update()
    mod=pcb.modifiers.new('PCB mounting holes','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
    baked=bpy.data.meshes.new_from_object(pcb.evaluated_get(bpy.context.evaluated_depsgraph_get()))
    old=pcb.data;pcb.modifiers.remove(mod);pcb.data=baked
    if old.users==0:bpy.data.meshes.remove(old)
    data=cutter.data;bpy.data.objects.remove(cutter,do_unlink=True)
    if data.users==0:bpy.data.meshes.remove(data)
    bpy.data.objects.remove(temporary.root,do_unlink=True)


def _usb_port(b,center,face='-Y',blue=True,width=.0135,height=.0062,depth=.009):
    """Open metal sleeve + dark cavity + projecting tongue. Local front is -Y."""
    rot=Matrix.Rotation(math.pi/2,3,'Z') if face=='+X' else Matrix.Rotation(-math.pi/2,3,'Z') if face=='-X' else Matrix.Rotation(math.pi,3,'Z') if face=='+Y' else Matrix.Identity(3)
    def cube(key,p,d): _box(b,key,rot@Vector(p)+Vector(center),d,.0002,.00008,1,rot)
    # Four real shell walls, rear cavity and tongue, not a painted port rectangle.
    cube('silver',(-width/2+.00035,0,0),(.0007,depth,height))
    cube('silver',(width/2-.00035,0,0),(.0007,depth,height))
    cube('silver',(0,0,height/2-.00035),(width,depth,.0007))
    cube('silver',(0,0,-height/2+.00035),(width,depth,.0007))
    cube('rubber',(0,depth/2-.00025,0),(width-.001,.0005,height-.001))
    cube('blue' if blue else 'rubber',(0,.0004,-.0010),(width-.0025,depth-.0014,.0015))
    for i in range(4):
        cube('silver',((i-1.5)*.0021,-.0010,-.00019),(.00075,.0035,.00011))


def _build_carrier(parent,m):
    b=_Bundle('EL_Carrier',parent,m)
    _box(b,'case',(0,0,.010),(.230,.160,.012),.008,.0012,4)
    # Raised anti-slip tracks and perimeter fasteners.
    for y in (-.063,.063): _box(b,'rubber',(0,y,.0168),(.209,.008,.0016),.003,.0002,2)
    for x in (-.095,.095):
        for y in (-.060,.060): _cylinder(b,'rubber',(x,y,.003),.010,.006,20)
    for x in (-.107,.107):
        for y in (-.070,.070): _screw(b,(x,y,.0167),.002)
    _text(b,'silver','ACQUISITION  /  SHADOW MODE',(0,-.071,.01611),.0033)
    b.root['dimensions_m']=[.230,.160,.0176]
    b.root['geometry_status']='designed carrier; not a BOM product'
    return b.finish()


def _build_pi(parent,m):
    px,py,_=PI_CENTER
    lower=_Bundle('EL_Pi5_Case_Lower',parent,m,PI_CENTER,(-.025,0,0))
    _box(lower,'case',(0,0,.021),(.100,.072,.006),.004,.0006,3)
    # Three sides; right side is a real continuous connector opening between rails.
    _box(lower,'case',(-.0487,0,.039),(.0026,.070,.032),.001,.00025,2)
    for y in (-.0347,.0347):
        _box(lower,'case',(0,y,.026),(.097,.0026,.004),.0008,.0002,2)
        _box(lower,'case',(0,y,.0535),(.097,.0026,.005),.0008,.0002,2)
        for x in [i*.006-.042 for i in range(15)]:
            if y>0 and -.040 < x < -.016:
                continue  # Purposeful 24 mm rear FPC service opening.
            _box(lower,'case',(x,y,.0385),(.0028,.0026,.021),.0006,.0002,1)
    for z,h in ((.025,.004),(.053,.006)):
        _box(lower,'case',(.0487,0,z),(.0026,.070,h),.0007,.0002,2)
    for y in (-.033,.033): _box(lower,'case',(.0487,y,.038),(.0026,.004,.022),.0006,.0002,2)
    for x in (-.039,.019):
        for y in (-.0245,.0245): _cylinder(lower,'silver',(x,y,.026),.0022,.007,12)
    lower.root['bom']='P03 Raspberry Pi 5 4GB; P05 fan case (design enclosure)'
    _anchor('EL_CSI_Case_Exit',lower.root,(-.030,.036,.040),(0,1,0))
    lower.finish()

    board=_Bundle('EL_Pi5_Board',parent,m,PI_CENTER,(0,0,.025))
    _box(board,'pcb',(0,0,.0303),(.085,.056,.0016),.0027,.00010,3)
    # Source mounting pattern: x=-39,+19 mm; y=+-24.5 mm relative PCB centre.
    for x in (-.039,.019):
        for y in (-.0245,.0245):
            _ring(board,'gold',(x,y,.03117),(.0058,.0058),(.0027,.0027),.00012,.00289,.001349,4)
    for x,y,w,d,h in ((-.010,.001,.015,.015,.002),(-.027,-.002,.010,.009,.0015),(.009,-.010,.008,.008,.0013),(.015,.014,.007,.007,.0014)):
        _box(board,'silicon',(x,y,.0311+h/2),(w,d,h),.00045,.0002,2)
    # Package terminals and a bounded, deliberately simplified passive population.
    for i in range(12):
        x=-.017+i*.0012
        for y in (-.0075,.0095): _box(board,'silver',(x,y,.0315),(.00055,.0010,.00045),.0001,.00005,1)
    for i in range(16):
        x=-.032+(i%8)*.006;y=-.018+(i//8)*.030
        _box(board,'silicon',(x,y,.03165),(.0024,.0013,.0010),.0001,.00006,1)
        for dx in (-.00125,.00125): _box(board,'silver',(x+dx,y,.03165),(.0005,.0013,.00085),.00008,.00005,1)
    for x,y in ((-.030,.009),(.013,-.019),(-.005,-.020)):
        _cylinder(board,'silver',(x,y,.0328),.0019,.0034,12)
        _cylinder(board,'silicon',(x,y,.0346),.0015,.00015,12,bevel=0)
    _box(board,'silicon',(-.010,.024,.0330),(.051,.005,.0034),.0005,.0002,2)
    for i in range(20):
        for y in (.0227,.0253): _box(board,'gold',(-.034+i*.00254,y,.037),(.00065,.00065,.005),.00009,.00004,1)
    _text(board,'silver','PI 5  |  4 GB',(-.025,-.014,.03118),.0022)
    # Two indicative FFC sockets; Camera Module 3 connects by FPC, not USB.
    for x in (-.033,-.022):
        _box(board,'silicon',(x,.014,.0325),(.008,.003,.0025),.00035,.0001,2)
        _box(board,'silver',(x,.0147,.0338),(.0075,.0007,.0005),.00015,.00005,1)
    _anchor('EL_CSI_Camera_In',board.root,(-.033,.014,.0338),(0,1,0))
    _anchor('EL_Pi_GPIO_I2C',board.root,(-.0315,.0253,.0395),(0,0,1))
    # microSD is an OS medium, not one of the mirrored data drives.
    _box(board,'silicon',(-.038,-.002,.0288),(.015,.011,.0010),.0007,.0001,2)
    for i in range(8): _box(board,'gold',(-.043+i*.0011,-.004,.02825),(.00065,.004,.00010),.00002,0,1)
    board.root['dimensions_m']=[.085,.056,.0016]
    board.root['source']=SOURCE_URLS['pi5']
    board.root['geometry_status']='PCB envelope/pattern sourced; populated component layout approximate'
    _drill_board(board.finish(),m)

    ports=_Bundle('EL_Pi5_Connectors',parent,m,PI_CENTER,(.024,0,.025))
    for y,blue in ((-.014,True),(.003,False)):
        for z in (.0345,.0420): _usb_port(ports,(.0435,y,z),'+X',blue)
    # RJ45 sleeve and eight contact fingers, opening out of the same short edge.
    _usb_port(ports,(.043,.023,.0380),'+X',False,.016,.013,.017)
    for y in [i*.00125+.0188 for i in range(8)]:
        _box(ports,'silver',(.0512,y,.0405),(.002,.00045,.00025),.00002,0,1)
    # USB-C power and two micro-HDMI connectors on long side.
    _usb_port(ports,(-.032,-.029,.033),'-Y',False,.009,.0035,.004)
    _anchor('EL_Pi_USB_C_In',ports.root,(-.032,-.031,.033),(0,-1,0))
    for x in (-.011,.003): _usb_port(ports,(x,-.029,.0325),'-Y',False,.0065,.003,.004)
    ports.finish()

    cooler=_Bundle('EL_Pi5_Fan_Cooler',parent,m,PI_CENTER,(0,0,.043))
    _box(cooler,'silver',(-.010,.001,.0351),(.014,.014,.004),.001,.0003,2)
    _box(cooler,'silver',(-.009,.000,.039),(.029,.027,.004),.002,.0005,3)
    for i in range(8): _box(cooler,'silver',(-.020+i*.0034,0,.045),(.0011,.025,.008),.00025,.00015,1)
    _cylinder(cooler,'rubber',(0,0,.052),.0137,.0045,24)
    _cylinder(cooler,'silver',(0,0,.0545),.0042,.0010,18)
    for i in range(7):
        a=i*math.tau/7;rot=Matrix.Rotation(a+.48,3,'Z')
        _box(cooler,'silver',(.0075*math.cos(a),.0075*math.sin(a),.0542),(.011,.004,.0007),.001,.0001,2,rot)
    cooler.finish()

    lid=_Bundle('EL_Pi5_Case_Lid',parent,m,PI_CENTER,(0,0,.063))
    _ring(lid,'case',(0,0,.0580),(.100,.072),(.032,.032),.0022,.004,.0158,6)
    for i in range(-5,6):
        y=i*.0025; half=math.sqrt(max(0,.0156**2-y*y))
        _box(lid,'case',(0,y,.0588),(2*half,.0010,.0010),.00045,.0001,2)
    for x in (-.044,.044):
        for y in (-.030,.030): _screw(lid,(x,y,.05925),.0015)
    _text(lid,'silver','ACQUISITION',(-.028,0,.05916),.0027,Matrix.Rotation(math.pi/2,3,'Z'))
    lid.finish()


def _build_rtc(parent,m):
    b=_Bundle('EL_DS3231_RTC',parent,m,(.042,.057,0),(0,.030,.023))
    _box(b,'rtc',(0,0,.027),(.033,.022,.0016),.0015,.0001,2)
    _box(b,'rubber',(-.007,0,.0297),(.010,.008,.0038),.0006,.0002,2)
    for x in (-.012,.012):
        for y in (-.007,.007): _cylinder(b,'silver',(x,y,.022),.0016,.008,10)
    _cylinder(b,'silver',(.006,0,.0300),.0061,.0024,20)
    _cylinder(b,'rubber',(.006,0,.03125),.0048,.0001,18,bevel=0)
    _text(b,'silver','RTC',(-.007,0,.0317),.0022)
    _usb_port(b,(.016,.001,.0295),'+X',False,.0047,.0033,.003)
    _anchor('EL_Ambient_I2C_In',b.root,(.0175,.001,.0295),(1,0,0))
    b.root['bom']='P08 DS3231; P09 CR1220; module PCB envelope is a design assumption'
    b.finish()


def _build_hub_and_drives(parent,m):
    h=_Bundle('EL_StarTech_ST53004U1C',parent,m,HUB_CENTER,(.035,0,.020))
    # Split housing leaves a fine parting seam; connectors protrude through an open fascia.
    _box(h,'case',(0,0,.02175),(.103,.060,.009),.004,.0007,3)
    _box(h,'case',(0,.003,.0347),(.103,.054,.0095),.004,.0007,3)
    _box(h,'case',(0,-.0295,.0365),(.098,.001,.0035),.0003,.0001,1)
    for x in (-.0345,-.0115,.0115,.0345):
        _usb_port(h,(x,-.029,.0305),'-Y',True)
        _cylinder(h,'blue_led',(x,-.018,.03965),.00065,.00015,10,bevel=0)
    _usb_port(h,(.033,.029,.0305),'+Y',False,.012,.0065,.007)
    _usb_port(h,(.033,.029,.035),'+Y',False,.008,.0032,.007)  # stepped USB3 Type-B upstream approximation
    _usb_port(h,(-.047,.011,.031),'-X',False,.0135,.0062,.007)  # dedicated charging position is approximate
    _cylinder(h,'silver',(-.027,.029,.031),.0032,.004,16,'Y')
    _cylinder(h,'rubber',(-.027,.0312,.031),.0022,.0003,14,'Y',0)
    _anchor('EL_Hub_DC_In',h.root,(-.027,.0312,.031),(0,1,0))
    _text(h,'silver','USB 3.0  /  POWERED',(0,.005,.03954),.003)
    h.root['dimensions_m']=[.103,.060,.022]
    h.root['source']=SOURCE_URLS['hub']
    h.root['geometry_status']='manufacturer envelope; port arrangement and casing detail visual approximation'
    _anchor('EL_USB_Thermal_Camera_In',h.root,(.0115,-.0335,.0305),(0,-1,0))
    _anchor('EL_USB_Auxiliary_In',h.root,(.0345,-.0335,.0305),(0,-1,0))
    h.finish()
    for index,x in enumerate((-.0345,-.0115)):
        # 42 mm complete length, with 9 mm inserted into the hub.
        origin=(HUB_CENTER[0]+x,HUB_CENTER[1]-.030,.0305)
        b=_Bundle('EL_Flash_Drive_'+('A' if index==0 else 'B'),parent,m,origin,(0,-.035-.013*index,.015))
        _box(b,'silver',(0,-.013,0),(.0122,.020,.0065),.0038,.00055,5)
        _box(b,'silver',(0,.003,0),(.0122,.012,.0046),.00065,.00018,2)
        _box(b,'blue',(0,.0086,-.0005),(.010,.0008,.0021),.0002,.00006,1)
        # Recessed dark lanyard aperture is a visible detail, not a mounted cable.
        _ring(b,'silver',(0,-.028,.0001),(.0122,.010),(.0055,.0038),.0065,.0038,.0018,4)
        _text(b,'silicon','256 GB',(0,-.017,.0033),.00175)
        _text(b,'silicon','A' if index==0 else 'B',(0,-.006,.0033),.0023)
        b.root['dimensions_m']=[.0122,.042,.0065]
        b.root['source']=SOURCE_URLS['flash']
        b.root['bom']='P14/P15 Raspberry Pi USB Flash Drive 256GB; not an SSD'
        b.finish()


def _build_leads(parent,m):
    b=_Bundle('EL_Acquisition_Leads',parent,m)
    # Pi USB -> hub upstream. Both ends have molded boots touching connector faces.
    _box(b,'rubber',(.001,-.006,.042),(.016,.009,.006),.0018,.0004,3)
    _box(b,'rubber',(.084,.036,.031),(.011,.014,.008),.0015,.0004,3)
    _tube(b,'rubber',[(.009,-.006,.042),(.023,-.002,.050),(.026,.040,.057),(.073,.049,.048),(.084,.043,.031)],.0019,8,6)
    # Actual device-end boots; the complete supply cables are built pose-aware below.
    _box(b,'rubber',(-.087,-.028,.033),(.009,.012,.004),.0015,.00025,3)
    _box(b,'rubber',(.024,.035,.031),(.008,.012,.008),.0016,.0003,3)
    # RTC I2C bundle, external to all animal space.
    for i in range(3):
        _tube(b,'rubber',[(.031,.057+i*.0011,.029),(.005,.058+i*.0011,.038),(-.054,.034+i*.0011,.039)],.00036,6,4)
    b.root['geometry_status']='signal routing and device power boots; complete power chain in EL_Power_Cables'
    b.finish()


def _build_ups(parent,m,ups_drop=0.0):
    b=_Bundle('EL_APC_BE600M1_UPS',parent,m,(UPS_CENTER[0],UPS_CENTER[1],float(ups_drop)),(.075,0,0))
    # Manufacturer outer envelope274x105x139mm, with separate upper outlet deck.
    _box(b,'case',(0,0,.0675),(.274,.105,.131),.009,.0018,5)
    _box(b,'case',(0,0,.1337),(.270,.102,.0066),.008,.0010,4)
    for x in (-.111,.111):
        for y in (-.034,.034): _cylinder(b,'rubber',(x,y,.003),.010,.006,16)
    # Fine ventilation grooves on visible sides; visually recessed, not a thermal simulation.
    rot=Matrix.Rotation(math.pi/2,3,'X')
    for x in [i*.006-.100 for i in range(34)]:
        _box(b,'rubber',(x,-.05265,.044),(.002,.024,.0005),.0008,.0001,2,rot)
    # Seven NEMA outlet faces; 5 backup and 2 surge-only as specified, no fabricated display.
    positions=[(-.098,-.021),(-.049,-.021),(0,-.021),(.049,-.021),(.098,-.021),(-.074,.023),(-.022,.023)]
    for i,(x,y) in enumerate(positions):
        _box(b,'case',(x,y,.1370),(.036,.029,.0008),.007,.0002,3)
        for dx,hh in ((-.006,.008),(.006,.0065)):
            _box(b,'rubber',(x+dx,y+.003,.13755),(.0023,hh,.0003),.0005,.00005,2)
        _cylinder(b,'rubber',(x,y-.007,.1376),.0028,.0003,12,bevel=0)
    _cylinder(b,'rubber',(.091,.023,.1380),.0095,.0018,22)
    _cylinder(b,'led',(.091,.023,.1390),.0058,.0002,20,bevel=0)
    # Charging port is distinct from the AC outlets.
    _box(b,'silver',(.035,.024,.1377),(.016,.010,.0008),.001,.0002,2)
    _box(b,'rubber',(.035,.024,.1382),(.013,.006,.0002),.0005,.00005,2)
    _text(b,'silver','BACK-UPS  600',(.065,-.05295,.099),.0055,rot)
    _text(b,'silver','BE600M1',(-.068,-.05295,.099),.0040,rot)
    for x in (-.123,.123):
        for y in (-.040,.040): _screw(b,(x,y,.1373),.002)
    # Short visible entry and resting disconnected mains lead; no cage actuator connection.
    _cylinder(b,'rubber',(.137,.018,.025),.0055,.012,14,'X')
    _tube(b,'rubber',[(.143,.018,.025),(.156,.019,.014),(.167,-.020,.006),(.150,-.061,.006),(.118,-.073,.006)],.0032,10,6)
    _box(b,'rubber',(.108,-.073,.008),(.024,.018,.014),.004,.0008,3)
    for y in (-.078,-.068): _box(b,'silver',(.090,y,.008),(.013,.0015,.006),.0003,.0001,1)
    _cylinder(b,'silver',(.090,-.073,.003),.0017,.013,12,'X',.0002)
    b.root['dimensions_m']=[.274,.105,.139]
    b.root['source']=SOURCE_URLS['ups']
    b.root['geometry_status']='manufacturer envelope; visible outlet/detail positions approximate; no internal battery model'
    _anchor('EL_UPS_AC_In',b.root,(.0835,-.073,.008),(-1,0,0))
    _anchor('EL_UPS_Backup_Out_1',b.root,(-.098,-.021,.139),(0,0,1))
    _anchor('EL_UPS_Backup_Out_2',b.root,(-.049,-.021,.139),(0,0,1))
    return b.finish()


def _build_power_chain(parent,ups,m,ups_drop):
    """Two separate, physically depicted AC/DC adapters; no AC-to-USB cable."""
    pi=_Bundle('EL_Pi_27W_Adapter',ups,m,explode=(0,0,.040))
    # Official Type-A body52x52x36mm, rotated to dock on an upward NEMA outlet.
    _box(pi,'psu',(-.098,-.021,.165),(.036,.052,.052),.006,.001,5)
    _box(pi,'psu',(-.098,-.021,.141),(.035,.051,.004),.005,.0005,4)
    _ring(pi,'rubber',(-.098,-.021,.144),(.0361,.0521),(.0353,.0513),.00045,.006,.0056,4)
    # Type-A blades extend into the documented backup outlet's two blade slots.
    for dx in (-.00635,.00635):
        _box(pi,'silver',(-.098+dx,-.018,.1305),(.0015,.006,.017),.00025,.0001,1)
    _cylinder(pi,'rubber',(-.117,-.021,.165),.0031,.004,16,'X')
    _text(pi,'rubber','27 W  /  USB-C',(-.098,-.021,.19108),.0034,Matrix.Rotation(math.pi/2,3,'Z'))
    _anchor('EL_Pi_27W_AC_In',pi.root,(-.098,-.021,.139),(0,0,-1))
    _anchor('EL_Primary_USB_C_Feed',pi.root,(-.119,-.021,.165),(-1,0,0))
    pi.root['bom']='P04 Raspberry Pi 27W USB-C Power Supply; Type-A body envelope'
    pi.root['source']=SOURCE_URLS['pi_psu'];pi.root['dimensions_m']=[.036,.052,.052]
    pi.root['power_role']='AC input from UPS backup outlet; captive USB-C DC output to Pi5'
    pi.finish()

    hub=_Bundle('EL_Hub_Power_Adapter',ups,m,explode=(0,0,.035))
    _box(hub,'case',(-.049,-.021,.1585),(.038,.048,.039),.005,.001,4)
    _ring(hub,'rubber',(-.049,-.021,.144),(.0381,.0481),(.0373,.0473),.0004,.005,.0046,4)
    for dx in (-.00635,.00635):
        _box(hub,'silver',(-.049+dx,-.018,.1305),(.0015,.006,.017),.00025,.0001,1)
    _cylinder(hub,'rubber',(-.049,.005,.158),.0031,.004,16,'Y')
    _text(hub,'silver','12 V  /  2 A',(-.049,-.021,.17808),.0032,Matrix.Rotation(math.pi/2,3,'Z'))
    _anchor('EL_Hub_Adapter_AC_In',hub.root,(-.049,-.021,.139),(0,0,-1))
    _anchor('EL_Hub_Adapter_DC_Out',hub.root,(-.049,.007,.158),(0,1,0))
    hub.root['bom']='P33 included hub AC adapter, 12V DC / 2A from StarTech specification'
    hub.root['source']=SOURCE_URLS['hub'];hub.root['dimensions_m']=[.038,.048,.039]
    hub.root['geometry_status']='adapter housing size/plug orientation designed; power role source-confirmed'
    hub.root['power_role']='AC input from separate UPS backup outlet; DC barrel output to hub'
    hub.finish()

    cables=_Bundle('EL_Power_Cables',parent,m)
    # The surplus of the specified1.2m Pi cable is restrained in the clear gap
    # between carrier (right edgeX=.115) and UPS (left edgeX=.203).
    radius=.018;cx=.188;cy=-.085
    coil=[]
    for i in range(65):
        a=math.pi/2+4*math.tau*i/64
        coil.append((cx+radius*math.cos(a),cy+radius*math.sin(a),ups_drop+.025-.018*i/64))
    pi_path=[(-.087,-.034,.033),(-.091,-.047,.025),(-.064,-.055,.022),
             (-.010,-.054,.022),(.050,-.073,.023),(.101,-.054,.025),
             (.106,.010,.030),(.105,.0735,.034),(.129,.065,.035),(.167,-.040,.034)]
    pi_path+=coil
    pi_path +=[(.214,-.058,ups_drop+.025),(.198,-.077,ups_drop+.080),
               (.202,-.064,ups_drop+.161),(.213,-.021,ups_drop+.165),(.221,-.021,ups_drop+.165)]
    pi_line=_tube(cables,'rubber',pi_path,.0017,8,3)
    hub_path=[(.024,.041,.031),(.028,.062,.024),(.069,.082,.022),(.113,.091,.025),
              (.169,.093,.034),(.214,.09,ups_drop+.090),(.261,.069,ups_drop+.145),
              (.286,.038,ups_drop+.158),(.291,.016,ups_drop+.158),(.291,.007,ups_drop+.158)]
    hub_line=_tube(cables,'rubber',hub_path,.0015,8,5)
    # Two small reusable straps support the coiled captive cable on the table.
    for y in (-.096,-.074):
        _ring(cables,'rubber',(.188,y,ups_drop+.01425),(.044,.0285),(.040,.0245),.0035,.003,.002,3,Matrix.Rotation(math.pi/2,3,'X'))
    cables.root['pi_cable_length_m']=sum((b-a).length for a,b in zip(pi_line,pi_line[1:]))
    cables.root['hub_cable_length_m']=sum((b-a).length for a,b in zip(hub_line,hub_line[1:]))
    cables.root['ups_drop_m']=float(ups_drop)
    cables.root['power_paths']=json.dumps({'pi_usb_c':pi_path,'hub_dc':hub_path})
    cables.root['power_chain']='UPS AC -> Pi27W adapter -> captive USB-C -> Pi5; UPS AC -> hub12V adapter -> barrel -> hub'
    cables.root['pose_note']='rebuild with ups_drop when changing table height; hide this group for exploded views'
    cables.finish()


def get_anchor_positions(root):
    """Live anchor coordinates, valid after parent translation/rotation and UPS pose."""
    bpy.context.view_layer.update();inverse=root.matrix_world.inverted();result={}
    for key,spec in ANCHORS.items():
        obj=next(o for o in root.children_recursive if o.name==spec['name'] or o.name.startswith(spec['name']+'.'))
        local=inverse@obj.matrix_world.translation
        normal=Vector(obj['connector_normal'])
        result[key]={'name':obj.name,'local_m':list(local),'world_m':list(obj.matrix_world.translation),
                     'normal_local':list((inverse.to_3x3()@obj.matrix_world.to_3x3()@normal).normalized()),
                     'normal_world':list((obj.matrix_world.to_3x3()@normal).normalized())}
    return result


def build_electronics(parent=None,ups_drop=0.0):
    """Return the independent acquisition+UPS assembly; no global scene side effects."""
    if not math.isfinite(float(ups_drop)):raise ValueError('ups_drop must be finite metres')
    root=bpy.data.objects.new('Electronics_Assembly',None)
    bpy.context.collection.objects.link(root)
    root.parent=parent
    root.location=(0,0,0)
    root.empty_display_type='PLAIN_AXES';root.empty_display_size=.05
    root['units']='metres';root['up_axis']='Z'
    root['status']='proposed cage-external monitoring electronics; no actuator or display'
    root['carrier_envelope_m']=[.23,.16,.10]
    root['ups_drop_m']=float(ups_drop)
    m=_palette()
    _build_carrier(root,m);_build_pi(root,m);_build_rtc(root,m)
    _build_hub_and_drives(root,m);_build_leads(root,m)
    ups=_build_ups(root,m,ups_drop);_build_power_chain(root,ups,m,float(ups_drop))
    meshes=[o for o in root.children_recursive if o.type=='MESH']
    triangles=0
    for obj in meshes:
        obj.data.calc_loop_triangles();triangles+=len(obj.data.loop_triangles)
    root['mesh_count']=len(meshes);root['triangle_count']=triangles
    if len(meshes)>45 or triangles>54000:
        raise RuntimeError('Electronics budget exceeded: %s meshes, %s triangles'%(len(meshes),triangles))
    return root
