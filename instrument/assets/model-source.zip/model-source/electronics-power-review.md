# Completed physical supply chain — asset review

2026-09-07. Updated only assets and QA records under `model-source`; no website or `build_instrument.py` edit.

The assembly now depicts two distinct paths:

- UPS backup outlet 1 → independent Raspberry Pi 27 W Type-A adapter → its captive USB-C lead → Pi 5 power port.
- UPS backup outlet 2 → independent hub AC adapter → its captive 12 V DC lead → hub barrel socket.

The adapters are physically seated on their own backup outlets and are children of `EL_APC_BE600M1_UPS`. AC entry and DC exit have separate anchors. The old miniature inline adapter placeholder and unused USB-C coupling block were removed. All original component names and the `build_electronics(parent=None)` calling convention remain available. `ups_drop` is optional and defaults to 0 for compatibility.

## Root integration

Use:

```python
electronics = build_electronics(assembly, ups_drop=-0.0255)
electronics.location = (0.216, 0.015, 0.026)
```

Delete the entire previous post-build adjustment block:

```python
ups = next(o for o in electronics.children if o.name == 'EL_APC_BE600M1_UPS')
ups.location.z -= .0345
for anchor in electronics.children:
    if anchor.type == 'EMPTY' and anchor.name.startswith('EL_UPS'):
        anchor.location.z -= .0345
```

At inspection this was `build_instrument.py` lines 187–191. It must not be retained with the new API: the UPS, adapters and cable routing are already generated for the requested pose. To change the pose later, rebuild with a new `ups_drop`; hide `EL_Power_Cables` for exploded views.

The master's bench top is world Z=0.0005 m. With root Z=0.026 m, drop −0.0255 m places the measured UPS foot bottom at Z=0.000500001 m. The previous −0.0345 m drop placed it 9 mm below that surface. Both poses were explicitly tested.

## Verified build and connections

Blender 4.5.13 builds **42 material meshes / 47,388 triangles**. This is 7 meshes / 5,198 triangles above the preceding asset, including the two adapters, complete wires and restrained surplus Pi cable. The configured ceiling is 45 meshes / 54,000 triangles.

`verify-electronics-power.py` passed all three drops (0, −0.0255, −0.0345 m). At the adopted pose:

- All 15 named anchor positions agree with expected local/world coordinates within 1e−6 m.
- Each adapter's AC anchor coincides with its UPS outlet anchor; the two normals point in opposite directions.
- Both DC cable ends meet the corresponding adapter output anchor, and the device ends meet their modeled strain-relief exits.
- No power-cable mesh vertex falls within either the main rig base-plate box or the UPS body box. Cable/strap minimum height stays at or above the bench. This is a conservative bounding-box/vertex check, not a general solid-intersection or electrical-clearance analysis.
- The Pi cable centreline is 1.23393 m, within the official reference dimension 1.2 m ±80 mm. The surplus is coiled forward of the UPS and beyond the right edge of the main rig plate. The hub cable is routed behind the acquisition carrier and around the UPS rear side.

The Pi adapter body is based on the manufacturer's 52 × 52 × 36 mm Type-A envelope. Its orientation is chosen to fit the upward-facing outlet. The hub adapter's 12 V / 2 A role is sourced, while its 38 × 48 × 39 mm housing and fine plug detail are designed approximations. [Pi power-supply drawing](https://datasheets.raspberrypi.com/power-supply/27w-usb-c-power-supply-product-brief.pdf), [StarTech hub/adapter specification](https://www.startech.com/en-us/usb-hubs/st53004u1c).

## Adopted power-anchor coordinates

Metres; `ups_drop=-0.0255`; root translation `(0.216,0.015,0.026)`; parent unrotated. Full signal and power anchors, normals and alternative poses are recorded in `electronics-power-validation.json`. For live transformed data call `get_anchor_positions(electronics)`.

| Anchor key | Assembly-local position | World position |
|---|---|---|
| `ups_backup_out_1` | `(0.242,−0.021,0.1135)` | `(0.458,−0.006,0.1395)` |
| `pi_adapter_ac_in` | `(0.242,−0.021,0.1135)` | `(0.458,−0.006,0.1395)` |
| `primary_usb_c_feed` | `(0.221,−0.021,0.1395)` | `(0.437,−0.006,0.1655)` |
| `pi_usb_c_in` | `(−0.087,−0.023,0.033)` | `(0.129,−0.008,0.059)` |
| `ups_backup_out_2` | `(0.291,−0.021,0.1135)` | `(0.507,−0.006,0.1395)` |
| `hub_adapter_ac_in` | `(0.291,−0.021,0.1135)` | `(0.507,−0.006,0.1395)` |
| `hub_adapter_dc_out` | `(0.291,0.007,0.1325)` | `(0.507,0.022,0.1585)` |
| `hub_dc_in` | `(0.024,0.0292,0.031)` | `(0.240,0.0442,0.057)` |
| `ups_ac_in_plug` | `(0.4235,−0.073,−0.0175)` | `(0.6395,−0.058,0.0085)` |

`primary_usb_c_feed` now names the real captive-cable exit on the Pi adapter. `hub_adapter_ac_in` moved from the removed placeholder to the actual depicted adapter's plug interface. Names are preserved, but callers must use current anchors rather than old numeric coordinates.

The UPS incoming mains plug remains visibly disconnected, so the model does not claim the proposed apparatus is operating. These are visual geometry and topology checks, not hardware manufacture, electrical validation or a claim of commercial verification.
