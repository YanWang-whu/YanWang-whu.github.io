# Proposed cage monitoring system

This is a reproducible design visualization for Yan Wang's September 2026 Unitree 天才少年计划 application. The application is under review. It is not production CAD, a manufactured instrument, or a record of an experiment.

## Rebuild

Use Blender 4.5 LTS (verified with 4.5.13). Keep these source files together. From the containing project directory:

```
blender --background --factory-startup --python model-source/build_instrument.py -- --round 5 --render --samples 64
blender --background --factory-startup --python model-source/calibration.py -- --render
```

The first command writes an editable `.blend`, a glTF 2.0 `.glb`, a geometry audit and a Cycles render to `model-output/round-5/`. Source units are metres, Z up. The glTF export is Y up. The second command builds the calibration accessories separately.

## Files

- `build_instrument.py`: cage, wire lid, cameras, adjustable supports, external ambient/optional piezo sensing and routing.
- `geometry.py`: geometry helpers and physical materials.
- `electronics.py`: acquisition assembly, power adapters, cables and connector anchors.
- `calibration.py`: independent calibration accessories.
- `electronics-manifest.md`, `electronics-power-review.md`, `calibration-assumptions.md`: sources, assumptions, connection coordinates and qualifications.
- `geometry-audit.json`: audit of the delivered main model.

## Source-based details

- Tecniplast 1264C body: 268 × 215 × 141 mm; the taper, wall thickness and wire-lid pattern are estimates.
- Camera Module 3 Wide NoIR PCB: 25 × 23.862 mm. Mounting holes are Ø2.2 mm on **21 × 12.5 mm** centers. The drawing's 14.5 mm dimension is from the upper row to the board edge, not the row-to-row spacing. The lens center is offset from the board center.
- PureThermal 3 PCB: 25.8 × 28.9 × 1.6 mm, Ø2.2 mm holes on 20.7 × 23.9 mm centers.
- Lepton core: 11.5 × 12.7 × 6.9 mm; 57° horizontal field. The 44° vertical field used for the visual overlay is a rounded aspect-ratio approximation.
- The external CSI ribbon is about 467.5 mm long, within the specified 500 mm allowance. This checks geometric length, not a production cable's bending or electrical performance.

Manufacturer documents are linked from the website's design notes; they are not bundled in this source archive. Camera carriers, enclosures, frame, cable guides and the overall layout are proposed rather than certified manufacturer CAD.

## Review history

An initial assembly and four subsequent revisions were reviewed.

1. Revised principal dimensions, real PCB/plate holes, ribbon routing and length, power adapters, grounded UPS/feet and product-render exposure.
2. Repaired planar shading after Boolean cuts, added sensor support, fixed semantic component selection/explosion and camera framing.
3. Corrected the Camera 3 hole and lens offsets from the original drawing, routed CSI clear of GPIO/PCB, supported the optional ADC, and added geometry-based grid-obstruction inspection. Fixed offscreen replay and readable mobile plots.
4. Seated camera insulating washers and fixing shafts, removed unused texture coordinates, refined fitting to visible parts, and verified the assembled/exploded reset behavior.

The model and browser checks do not establish manufacturing readiness, thermal accuracy, electrical compliance, or biological classification performance. Replay values are scripted examples, and sampled obstruction is a property of the illustrative grid geometry only.
